<?xml version="1.0" encoding="UTF-8"?>
<sch:schema xmlns:sch="http://purl.oclc.org/dsdl/schematron" queryBinding="xslt2">
  <sch:ns prefix="f" uri="http://hl7.org/fhir"/>
  <sch:ns prefix="h" uri="http://www.w3.org/1999/xhtml"/>
  <!-- 
    This file contains just the constraints for the profile CapabilityStatement
    It includes the base constraints for the resource as well.
    Because of the way that schematrons and containment work, 
    you may need to use this schematron fragment to build a, 
    single schematron that validates contained resources (if you have any) 
  -->
  <sch:pattern>
    <sch:title>f:CapabilityStatement</sch:title>
    <sch:rule context="f:CapabilityStatement">
      <sch:assert test="count(f:extension[@url = 'https://fhir.inera.se/ig/tjanstekatalog/StructureDefinition/tk-api-specification-category']) &lt;= 1">extension with URL = 'https://fhir.inera.se/ig/tjanstekatalog/StructureDefinition/tk-api-specification-category': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'https://fhir.inera.se/ig/tjanstekatalog/StructureDefinition/tk-api-specification-source-reference']) &lt;= 1">extension with URL = 'https://fhir.inera.se/ig/tjanstekatalog/StructureDefinition/tk-api-specification-source-reference': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'https://fhir.inera.se/ig/tjanstekatalog/StructureDefinition/tk-capabilitystatement-responsible-organization']) &lt;= 1">extension with URL = 'https://fhir.inera.se/ig/tjanstekatalog/StructureDefinition/tk-capabilitystatement-responsible-organization': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:url) &gt;= 1">url: minimum cardinality of 'url' is 1</sch:assert>
      <sch:assert test="count(f:version) &gt;= 1">version: minimum cardinality of 'version' is 1</sch:assert>
      <sch:assert test="count(f:title) &gt;= 1">title: minimum cardinality of 'title' is 1</sch:assert>
      <sch:assert test="count(f:rest) &gt;= 1">rest: minimum cardinality of 'rest' is 1</sch:assert>
      <sch:assert test="count(f:rest) &lt;= 1">rest: maximum cardinality of 'rest' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
</sch:schema>
