# Tjänstekatalogen administratörsbehörighet - Tjänstekatalogen v0.1.1

## Resursprofil: Tjänstekatalogen administratörsbehörighet 

**Användningar:**

* Referera till denna Profil: [Tjänstekatalogen Provenance](StructureDefinition-tk-provenance.md)
* Exempel för denna Profil: [PractitionerRole/TKCentralAdministratorRoleExample](PractitionerRole-TKCentralAdministratorRoleExample.md) and [PractitionerRole/TKLocalAdministratorRoleExample](PractitionerRole-TKLocalAdministratorRoleExample.md)
* CapabilityStatements som använder denna Profil: [Tjänstekatalogen: administrativt API](CapabilityStatement-tk-admin-api.md)

Du kan också kontrollera [användningar i FHIR IG-statistiken](https://packages2.fhir.org/xig/resource/inera.infra.tjanstekatalog|current/StructureDefinition/StructureDefinition-tk-administrator-role.json)

### Formella vyer av profilinnehåll

 [Beskrivningsdifferentialer, ögonblicksbilder och andra representationer](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Tabell med nyckelelement](#tabs-key) 
*  [Differentialtabell](#tabs-diff) 
*  [Ögonblicksbildstabell](#tabs-snap) 
*  [Statistik/referenser](#tabs-summ) 
*  [Alla](#tabs-all) 

#### Terminologibindningar

#### Begränsningar

Denna struktur är härledd från [PractitionerRole](http://hl7.org/fhir/R5/practitionerrole.html) 

#### Terminologibindningar (differential)

#### Terminologibindningar

#### Begränsningar

Denna struktur är härledd från [PractitionerRole](http://hl7.org/fhir/R5/practitionerrole.html) 

 **Vy med nyckelelement** 

#### Terminologibindningar

#### Begränsningar

 **Differentialvy** 

Denna struktur är härledd från [PractitionerRole](http://hl7.org/fhir/R5/practitionerrole.html) 

#### Terminologibindningar (differential)

 **ÖgonblicksbildsvyView** 

#### Terminologibindningar

#### Begränsningar

Denna struktur är härledd från [PractitionerRole](http://hl7.org/fhir/R5/practitionerrole.html) 

 

Andra representationer av profilen: [CSV](../StructureDefinition-tk-administrator-role.csv), [Excel](../StructureDefinition-tk-administrator-role.xlsx), [Schematron](../StructureDefinition-tk-administrator-role.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "tk-administrator-role",
  "url" : "https://fhir.inera.se/ig/tjanstekatalog/StructureDefinition/tk-administrator-role",
  "identifier" : [{
    "value" : "TKAdministratorRole"
  }],
  "version" : "0.1.1",
  "name" : "TKAdministratorRole",
  "title" : "Tjänstekatalogen administratörsbehörighet",
  "status" : "draft",
  "date" : "2026-09-08",
  "publisher" : "Inera AB",
  "contact" : [{
    "name" : "Inera AB",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Behörighet för en administratör att registrera/ändra poster i\ntjänstekatalogen för en given organisation (`local-admin`), eller att\ndessutom administrera andra administratörers behörigheter för samtliga\norganisationer (`central-admin`, `organization` utelämnad). Se\n[Roller och ansvar](roles-and-responsibilities.html) och\n[Kravkatalog](requirements.html) REQ-ADM-*.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "SE",
      "display" : "Sweden"
    }]
  }],
  "fhirVersion" : "5.0.0",
  "mapping" : [{
    "identity" : "req",
    "uri" : "https://fhir.inera.se/ig/tjanstekatalog/Requirements/tk-tjanstekatalog-requirements",
    "name" : "Kravkatalog"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 V2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "interface",
    "uri" : "http://hl7.org/fhir/interface",
    "name" : "Interface Pattern"
  },
  {
    "identity" : "servd",
    "uri" : "http://www.omg.org/spec/ServD/1.0/",
    "name" : "ServD"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "PractitionerRole",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/PractitionerRole",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "PractitionerRole",
      "path" : "PractitionerRole"
    },
    {
      "id" : "PractitionerRole.id",
      "path" : "PractitionerRole.id",
      "mustSupport" : true,
      "mapping" : [{
        "identity" : "req",
        "map" : "REQ-ADM-1"
      }]
    },
    {
      "id" : "PractitionerRole.active",
      "path" : "PractitionerRole.active",
      "short" : "Om behörigheten gäller (false = återkallad)",
      "mustSupport" : true,
      "mapping" : [{
        "identity" : "req",
        "map" : "REQ-ADM-4"
      }]
    },
    {
      "id" : "PractitionerRole.period",
      "path" : "PractitionerRole.period",
      "short" : "Behörighetens giltighetsperiod",
      "mustSupport" : true,
      "mapping" : [{
        "identity" : "req",
        "map" : "REQ-ADM-4"
      }]
    },
    {
      "id" : "PractitionerRole.period.start",
      "path" : "PractitionerRole.period.start",
      "mustSupport" : true
    },
    {
      "id" : "PractitionerRole.period.end",
      "path" : "PractitionerRole.period.end",
      "mustSupport" : true
    },
    {
      "id" : "PractitionerRole.practitioner",
      "path" : "PractitionerRole.practitioner",
      "short" : "Kontot/systemet som innehar behörigheten",
      "mustSupport" : true,
      "mapping" : [{
        "identity" : "req",
        "map" : "REQ-ADM-3"
      }]
    },
    {
      "id" : "PractitionerRole.organization",
      "path" : "PractitionerRole.organization",
      "short" : "Organisationen administratören representerar (utelämnad för central-admin = alla)",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://fhir.inera.se/ig/tjanstekatalog/StructureDefinition/tk-organization"]
      }],
      "mustSupport" : true,
      "mapping" : [{
        "identity" : "req",
        "map" : "REQ-ADM-2"
      }]
    },
    {
      "id" : "PractitionerRole.code",
      "path" : "PractitionerRole.code",
      "short" : "Administrationsnivå (local-admin/central-admin)",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true,
      "binding" : {
        "strength" : "example",
        "valueSet" : "https://fhir.inera.se/ig/tjanstekatalog/ValueSet/tk-administrator-role"
      },
      "mapping" : [{
        "identity" : "req",
        "map" : "REQ-ADM-1"
      }]
    }]
  }
}

```
