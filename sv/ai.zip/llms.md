# inera.infra.tjanstekatalog#0.2.0: Tjänstekatalogen(sv)

## Pages

* [Hem](index.md)
* [Nedladdningar](downloads.md)
* [Säkerhet och behörighet](security.md)
* [CapabilityStatement](capabilitystatement.md)
* [Inledning](introduction.md)
* [Förväntade svar](expected-responses.md)
* [Kravkatalog](requirements.md)
* [Informationsunderlag](information-basis.md)
* [Testning och validering](testing.md)
* [Mappning till profiler](mappings.md)
* [Användningsfall](use-cases.md)
* [Felhantering](error-handling.md)
* [Sammanfattning av artefakter](artifacts.md)
* [Roller och ansvar](roles-and-responsibilities.md)
* [Versionshistorik](version-history.md)
* [Om](about.md)
* [REST-interaktioner och sökparametrar](rest-interactions.md)

## Resources

### CodeSystems

* [Kategorier för API-specifikationer (kodsystem)](CodeSystem-tk-api-specification-category.md)
* [Säkerhetsmetoder för tekniska ändpunkter (kodsystem)](CodeSystem-tk-endpoint-security-method.md)

### ValueSets

* [Kategorier för API-specifikationer](ValueSet-tk-api-specification-category.md)
* [Säkerhetsmetoder för tekniska ändpunkter](ValueSet-tk-endpoint-security-method.md)

### Resource Profiles

* [Tjänstekatalogen API-instans](StructureDefinition-tk-api-instance.md)
* [Tjänstekatalogen API-specifikation](StructureDefinition-tk-api-specification-capability.md)
* [Tjänstekatalogen Endpoint](StructureDefinition-tk-endpoint.md)
* [Tjänstekatalogen OperationOutcome](StructureDefinition-tk-operation-outcome.md)
* [Tjänstekatalogen Organization](StructureDefinition-tk-organization.md)
* [Tjänstekatalogen Provenance](StructureDefinition-tk-provenance.md)

### Extensions

* [Tillgängliggörande ändpunkt](StructureDefinition-tk-api-instance-endpoint.md)
* [API-instansens giltighetsperiod](StructureDefinition-tk-api-instance-period.md)
* [Specifikationskategori](StructureDefinition-tk-api-specification-category.md)
* [Referens till källa](StructureDefinition-tk-api-specification-source-reference.md)
* [Ansvarig organisation (strukturerad referens)](StructureDefinition-tk-capabilitystatement-responsible-organization.md)
* [URL till auktorisationsserver](StructureDefinition-tk-endpoint-authorization-server-url.md)
* [Stödd specifikation (payload profile)](StructureDefinition-tk-endpoint-payload-profile.md)
* [Säkerhetsmetod](StructureDefinition-tk-endpoint-security-method.md)

### ActorDefinitions

* [Synkroniseringstjänst](ActorDefinition-tk-synkroniseringstjanst.md)

### CapabilityStatements

* [Tjänstekatalogen: administrativt API](CapabilityStatement-tk-admin-api.md)
* [Tjänstekatalogen: sök-API (externt)](CapabilityStatement-tk-search-api.md)

### ImplementationGuides

* [Tjänstekatalogen](ImplementationGuide-inera.infra.tjanstekatalog.md)

### NamingSystems

* [HSA-id](NamingSystem-hsa-id.md)
* [Organisationsnummer](NamingSystem-organisationsnummer.md)

### Requirements

* [Kravkatalog: Tjänstekatalogen](Requirements-tk-tjanstekatalog-requirements.md)

### SearchParameters

* [CapabilityStatement: instantiates](SearchParameter-tk-capabilitystatement-instantiates.md)
* [CapabilityStatement: kind](SearchParameter-tk-capabilitystatement-kind.md)
* [Endpoint: implements](SearchParameter-tk-endpoint-implements.md)
* [Endpoint: listed-by](SearchParameter-tk-endpoint-listed-by.md)

### SubscriptionTopics

* [Ändringar i Organisation/Ändpunkt](SubscriptionTopic-tk-organization-endpoint-changes.md)

### Examples

* [TKAPIInstanceExample (CapabilityStatement)](CapabilityStatement-TKAPIInstanceExample.md)
* [Patientinformation (Inera FHIR IG) (CapabilityStatement)](CapabilityStatement-TKAPISpecificationCapabilityExample.md)
* [Exempelregionens patientinformations-API (Endpoint)](Endpoint-TKEndpointExample.md)
* [TKOperationOutcomeExample (OperationOutcome)](OperationOutcome-TKOperationOutcomeExample.md)
* [Exempelregionen (Organization)](Organization-TKOrganizationExample.md)
* [Exempelregionens vårdcentral (Organization)](Organization-TKOrganizationUnitExample.md)
* [TKProvenanceExample (Provenance)](Provenance-TKProvenanceExample.md)
