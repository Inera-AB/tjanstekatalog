# inera.core.template#2.2.1: Inera FHIR Implementation Guide Template(sv)

## Pages

* [Hem](index.md)
* [Om](about.md)
* [Mappning till profiler](mappings.md)
* [Användningsfall](use-cases.md)
* [Förväntade svar](expected-responses.md)
* [Informationsunderlag](information-basis.md)
* [Testning och validering](testing.md)
* [Felhantering](error-handling.md)
* [REST-interaktioner och sökparametrar](rest-interactions.md)
* [Säkerhet och behörighet](security.md)
* [Sammanfattning av artefakter](artifacts.md)
* [Inledning](introduction.md)
* [Roller och ansvar](roles-and-responsibilities.md)
* [Nedladdningar](downloads.md)
* [CapabilityStatement](capabilitystatement.md)
* [Versionshistorik](version-history.md)

## Resources

### Resource Profiles

* [Inera Patient](StructureDefinition-IneraPatient.md)

### ImplementationGuides

* [Inera FHIR Implementation Guide Template](ImplementationGuide-inera.core.template.md)

### Examples

* [IneraPatientExample (Patient)](Patient-IneraPatientExample.md)
