# inera.tjanstekatalog#0.1.0: Tjänstekatalogen(sv)

## Pages

* [Hem](index.md)
* [Om](about.md)
* [Mappning till profiler](mappings.md)
* [Kravkatalog](requirements.md)
* [Användningsfall](use-cases.md)
* [Förväntade svar](expected-responses.md)
* [Informationsunderlag](information-basis.md)
* [Testning och validering](testing.md)
* [Felhantering](error-handling.md)
* [REST-interaktioner och sökparametrar](rest-interactions.md)
* [Säkerhet och behörighet](security.md)
* [Sammanfattning av artefakter](artifacts.md)
* [Inledning](introduction.md)
* [Roller och ansvar](roles-and-responsibilities.md)
* [Nedladdningar](downloads.md)
* [CapabilityStatement](capabilitystatement.md)
* [Versionshistorik](version-history.md)

## Resources

### CodeSystems

* [Säkerhetsmetoder för tekniska ändpunkter (kodsystem)](CodeSystem-tk-endpoint-security-method.md)

### ValueSets

* [Säkerhetsmetoder för tekniska ändpunkter](ValueSet-tk-endpoint-security-method.md)

### Logicals

* [API-specifikation (logisk modell)](StructureDefinition-tk-api-specification.md)
* [Indexpost (logisk modell)](StructureDefinition-tk-indexpost.md)
* [Vård- och omsorgstagare (logisk modell)](StructureDefinition-tk-vard-och-omsorgstagare.md)

### Resource Profiles

* [Inera Patient](StructureDefinition-IneraPatient.md)
* [Tjänstekatalogen Endpoint](StructureDefinition-tk-endpoint.md)
* [Tjänstekatalogen Organization](StructureDefinition-tk-organization.md)

### Extensions

* [URL till auktorisationsserver](StructureDefinition-tk-endpoint-authorization-server-url.md)
* [Stödd specifikation (payload profile)](StructureDefinition-tk-endpoint-payload-profile.md)
* [Säkerhetsmetod](StructureDefinition-tk-endpoint-security-method.md)

### ActorDefinitions

* [Synkroniseringstjänst](ActorDefinition-tk-synkroniseringstjanst.md)

### CapabilityStatements

* [Tjänstekatalogen: administrativt API](CapabilityStatement-tk-admin-api.md)

### ImplementationGuides

* [Tjänstekatalogen](ImplementationGuide-inera.tjanstekatalog.md)

### Requirements

* [Kravkatalog: Tjänstekatalogen](Requirements-tk-tjanstekatalog-requirements.md)

### SearchParameters

* [Endpoint: listed-by](SearchParameter-tk-endpoint-listed-by.md)

### Examples

* [Exempelregionens patientinformations-API (Endpoint)](Endpoint-TKEndpointExample.md)
* [Exempelregionen (Organization)](Organization-TKOrganizationExample.md)
* [IneraPatientExample (Patient)](Patient-IneraPatientExample.md)
