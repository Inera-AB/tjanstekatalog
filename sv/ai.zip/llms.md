# inera.infra.tjanstekatalog#0.1.0: Tjänstekatalogen(sv)

## Pages

* [Hem](index.md)
* [Nedladdningar](downloads.md)
* [Testning och validering](testing.md)
* [Förväntade svar](expected-responses.md)
* [CapabilityStatement](capabilitystatement.md)
* [Felhantering](error-handling.md)
* [Sammanfattning av artefakter](artifacts.md)
* [Användningsfall](use-cases.md)
* [Informationsunderlag](information-basis.md)
* [REST-interaktioner och sökparametrar](rest-interactions.md)
* [Versionshistorik](version-history.md)
* [Inledning](introduction.md)
* [Kravkatalog](requirements.md)
* [Om](about.md)
* [Mappning till profiler](mappings.md)
* [Roller och ansvar](roles-and-responsibilities.md)
* [Säkerhet och behörighet](security.md)

## Resources

### CodeSystems

* [Administratörsroller (kodsystem)](CodeSystem-tk-administrator-role.md)
* [Säkerhetsmetoder för tekniska ändpunkter (kodsystem)](CodeSystem-tk-endpoint-security-method.md)

### ValueSets

* [Administratörsroller](ValueSet-tk-administrator-role.md)
* [Säkerhetsmetoder för tekniska ändpunkter](ValueSet-tk-endpoint-security-method.md)

### Logicals

* [Indexpost (logisk modell)](StructureDefinition-tk-indexpost.md)
* [Vård- och omsorgstagare (logisk modell)](StructureDefinition-tk-vard-och-omsorgstagare.md)

### Resource Profiles

* [Inera Patient](StructureDefinition-IneraPatient.md)
* [Tjänstekatalogen administratörsbehörighet](StructureDefinition-tk-administrator-role.md)
* [Tjänstekatalogen API-instans](StructureDefinition-tk-api-instance.md)
* [Tjänstekatalogen API-specifikation](StructureDefinition-tk-api-specification-capability.md)
* [Tjänstekatalogen Endpoint](StructureDefinition-tk-endpoint.md)
* [Tjänstekatalogen Organization](StructureDefinition-tk-organization.md)
* [Tjänstekatalogen Provenance](StructureDefinition-tk-provenance.md)

### Extensions

* [Tillgängliggörande ändpunkt](StructureDefinition-tk-api-instance-endpoint.md)
* [API-instansens giltighetsperiod](StructureDefinition-tk-api-instance-period.md)
* [Specifikationskategori](StructureDefinition-tk-api-specification-category.md)
* [Referens till källa](StructureDefinition-tk-api-specification-source-reference.md)
* [Ansvarig organisation (strukturerad referens)](StructureDefinition-tk-capabilitystatement-responsible-organization.md)
* [URL till auktorisationsserver](StructureDefinition-tk-endpoint-authorization-server-url.md)
* [Stödd specifikation (payload profile)](StructureDefinition-tk-endpoint-payload-profile.md)
* [Säkerhetsmetod](StructureDefinition-tk-endpoint-security-method.md)

### ActorDefinitions

* [Synkroniseringstjänst](ActorDefinition-tk-synkroniseringstjanst.md)

### CapabilityStatements

* [Tjänstekatalogen: administrativt API](CapabilityStatement-tk-admin-api.md)
* [Tjänstekatalogen: sök-API (externt)](CapabilityStatement-tk-search-api.md)

### ImplementationGuides

* [Tjänstekatalogen](ImplementationGuide-inera.infra.tjanstekatalog.md)

### NamingSystems

* [HSA-id](NamingSystem-hsa-id.md)
* [Organisationsnummer](NamingSystem-organisationsnummer.md)

### Requirements

* [Kravkatalog: Tjänstekatalogen](Requirements-tk-tjanstekatalog-requirements.md)

### SearchParameters

* [CapabilityStatement: instantiates](SearchParameter-tk-capabilitystatement-instantiates.md)
* [CapabilityStatement: kind](SearchParameter-tk-capabilitystatement-kind.md)
* [Endpoint: implements](SearchParameter-tk-endpoint-implements.md)
* [Endpoint: listed-by](SearchParameter-tk-endpoint-listed-by.md)

### SubscriptionTopics

* [Ändringar i Organisation/Ändpunkt](SubscriptionTopic-tk-organization-endpoint-changes.md)

### Examples

* [TKAPIInstanceExample (CapabilityStatement)](CapabilityStatement-TKAPIInstanceExample.md)
* [Patientinformation (Inera FHIR IG) (CapabilityStatement)](CapabilityStatement-TKAPISpecificationCapabilityExample.md)
* [Exempelregionens patientinformations-API (Endpoint)](Endpoint-TKEndpointExample.md)
* [Exempelregionen (Organization)](Organization-TKOrganizationExample.md)
* [Exempelregionens vårdcentral (Organization)](Organization-TKOrganizationUnitExample.md)
* [IneraPatientExample (Patient)](Patient-IneraPatientExample.md)
* [TKCentralAdministratorRoleExample (PractitionerRole)](PractitionerRole-TKCentralAdministratorRoleExample.md)
* [TKLocalAdministratorRoleExample (PractitionerRole)](PractitionerRole-TKLocalAdministratorRoleExample.md)
* [TKProvenanceAdministratorRoleExample (Provenance)](Provenance-TKProvenanceAdministratorRoleExample.md)
* [TKProvenanceExample (Provenance)](Provenance-TKProvenanceExample.md)
